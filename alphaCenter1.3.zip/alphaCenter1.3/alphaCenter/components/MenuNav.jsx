import styles from './MenuNav.module.css'

export default function MenuNav({ setPage }) {

  const isActive = (page) => activePage === page ? styles.activeLink : '';
  return (
      <nav className={`bg-black ${styles.nav}`}>
      <ul className={`nav justify-content-center m-0 ${styles.nav}`}>
          <li className="nav-item">
            <a className="nav-link" href="#" onClick={() => setPage('Home')}>Home</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#" onClick={() => setPage('Eve')}>Events</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#" onClick={() => setPage('Contact')}>Contact</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#" onClick={() => setPage('FAQ')}>FAQ</a>
          </li>
        </ul>
      </nav>
    );
  }
  