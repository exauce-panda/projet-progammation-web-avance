import { useState } from 'react';
import Image from "next/image";
import styles from './Events.module.css';

import imgEven1 from "@/public/MainEventImage/kcx.png";
import imgEven2 from "@/public/MainEventImage/elevenallstar.jpeg";
import imgEven3 from "@/public/MainEventImage/evenBox.png";
import imgEven4 from "@/public/MainEventImage/superBall.jpg";

const eventsData = [
  {
    id: 1,
    imageSrc: imgEven1,
    title: "KCX KCORP VS THE WORLD",
    date: "Jeudi 8 Fevrier 2024",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente velit hic obcaecati modi sequi molestiae, debitis recusandae incidunt voluptates repellat, voluptatibus nam amet enim iure, ex tempora sunt nisi vero?",
  },
  {
    id: 2,
    imageSrc: imgEven2,
    title: "ELEVEN ALL STARS",
    date: "Samedi 19 Novembre 2024",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente velit hic obcaecati modi sequi molestiae, debitis recusandae incidunt voluptates repellat, voluptatibus nam amet enim iure, ex tempora sunt nisi vero?",
  },
  {
    id: 3,
    imageSrc: imgEven3,
    title: "KCX KCORP VS THE WORLD",
    date: "Jeudi 8 Fevrier 2024",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente velit hic obcaecati modi sequi molestiae, debitis recusandae incidunt voluptates repellat, voluptatibus nam amet enim iure, ex tempora sunt nisi vero?",
  },
  {
    id: 4,
    imageSrc: imgEven4,
    title: "ELEVEN ALL STARS",
    date: "Samedi 19 Novembre 2024",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente velit hic obcaecati modi sequi molestiae, debitis recusandae incidunt voluptates repellat, voluptatibus nam amet enim iure, ex tempora sunt nisi vero?",
  }
];


export default function Events() {
  
  const [currentPage, setCurrentPage] = useState(1);
  const eventsPerPage = 2;

  const indexOfLastEvent = currentPage * eventsPerPage;
  const indexOfFirstEvent = indexOfLastEvent - eventsPerPage;
  const currentEvents = eventsData.slice(indexOfFirstEvent, indexOfLastEvent);

  const totalPages = Math.ceil(eventsData.length / eventsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className={`container my-1 py-5 mx-auto`}>
      <div className="row">
        {currentEvents.map((event) => (
          <div className={`col-sm-6 mb-5 event-card text-center`} key={event.id}>
            <Image src={event.imageSrc} alt={`Image for ${event.title}`} className={`${styles.imgEv} mb-5`} />
            <h2 className={`${styles.titleEven} `}>{event.title}</h2>
            <p className={`${styles.dateEven}`}>{event.date}</p>
            <div className="d-flex flex-column align-items-center mt-3">
              <p className={`description ${styles.descEven} mb-3 text-start`}>{event.description}</p>
              <button className={`${styles.btnEven} btn btn-danger w-100 `}>Take a Ticket</button> 
            </div> 
          </div>
        ))}
      </div>
      <div className="pagination">
        {Array.from({ length: totalPages }, (_, index) => (
          <button
            key={index}
            className={`btn ${currentPage === index + 1 ? 'btn-danger' : 'btn-secondary'}`}
            onClick={() => handlePageChange(index + 1)}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
}
