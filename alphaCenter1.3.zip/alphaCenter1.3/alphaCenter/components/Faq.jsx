import styles from './Faq.module.css'


export default function Faq() {
    return (
      <div className="container py-5">
        <h1 className="text-center mb-4">Foire aux questions (FAQ)</h1>
        <div class="accordion" id="accordionFAQ">
          <div class={`accordion-item`}>
            <h2 class="accordion-header" id="headingOne">
              <button class={`accordion-button`} type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                Question 1: Comment acheter des billets?
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionFAQ">
              <div class="accordion-body">
                Vous pouvez acheter des billets directement sur notre site web dans la section Billetterie ou aux différents points de vente indiqués sur la page de l'événement.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                Question 2: Quelles sont les mesures sanitaires en place?
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionFAQ">
              <div class="accordion-body">
                Nous suivons les directives gouvernementales. Veuillez consulter la page de l'événement spécifique pour les mesures sanitaires les plus à jour.
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                Question 3: Puis-je obtenir un remboursement si je ne peux pas assister?
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionFAQ">
              <div class="accordion-body">
                Les remboursements sont possibles sous certaines conditions. Veuillez consulter notre politique de remboursement ou contactez le service client pour plus d'informations.
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  