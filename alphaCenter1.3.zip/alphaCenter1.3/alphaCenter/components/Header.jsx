import Image from "next/image";
import logo from "@/public/logo.png";
import MenuNav from "./MenuNav";

export default function Header({ setPage }) {

  return (
    <header >
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid justify-content-center">
          <a className="navbar-brand d-flex align-items-center justify-content-center" href="#">
            <Image src={logo} alt="logo Alpha center" width={80} height={80} />
            <h1 className="ms-3 mb-0">Alpha Center</h1>
          </a>
        </div>
      </nav>
      <div className="bg-dark text-white">
        <div className="container-fluid p-0">
          <MenuNav setPage={setPage} />
        </div>
      </div>
    </header>
  );
}
