export default function Contact({setPage}){
    return <>
         <div className="container">
        <div className="row">
          <div className="col">
            <h1 className="text-white">Contactez-nous</h1>
            <p className="text-white">Vous pouvez nous contacter de différentes manières :</p>
          </div>
        </div>
        <div className="row">
          <div className="col-md-6">
            <div className="bg-white p-4 rounded">
              <h2>CONTACTEZ-NOUS</h2>
              <form>
                <div className="mb-3">
                  <label htmlFor="nom" className="form-label">Nom</label>
                  <input type="text" className="form-control" id="nom" />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Adresse e-mail</label>
                  <input type="email" className="form-control" id="email" />
                </div>
                <div className="mb-3">
                  <label htmlFor="message" className="form-label">Message</label>
                  <textarea className="form-control" id="message" rows="5"></textarea>
                </div>
                <button type="btn" className="btn btn-dark" onClick={() => {
                  setPage('Contact')
                  console.log('Hello world')
                  }}>Envoyer</button>
              </form>
            </div>
          </div>
          <div className="col-md-6">
            <div className="bg-white p-4 rounded">
              <h2>Coordonnées</h2>
              <p>Vous pouvez également nous contacter directement via nos coordonnées :</p>
              <ul>
                <li>Téléphone : +1234567890</li>
                <li>Adresse e-mail : contact@example.com</li>
                <li>Adresse postale : 123 Rue de la Contact, Ville, Pays</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
}