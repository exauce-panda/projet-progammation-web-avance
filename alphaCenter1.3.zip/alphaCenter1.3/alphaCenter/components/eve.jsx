import Image from "next/image";
import styles from './eve.module.css';
import Events from './Events'

export default function Eve() {

  return (
    <>
      <div className={styles.eventsMain}>
        <Events />
      </div>
    </>
  );
}
