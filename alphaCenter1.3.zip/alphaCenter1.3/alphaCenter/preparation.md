Description du Projet
Notre projet consiste à créer un site web appelé "Alpha Center" qui présentera une variété d'événements axés sur différents sports, notamment le rugby, la boxe, etc.

Nous offrirons la possibilité à nos utilisateurs d'acheter des billets pour assister à ces différents événements sportifs.

Couleurs Utilisées
Azure (couleur principale)
Noir (#000) pour des accents et éléments de design
Site de Références
Pour le système de billetterie, nous nous inspirons du site :
EventTicketsCenter

Pour consulter le wireframe du projet, veuillez vous référer au dossier "Wireframe Images" dans notre documentation.