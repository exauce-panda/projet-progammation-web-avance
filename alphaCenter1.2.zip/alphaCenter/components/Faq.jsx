export default function Faq(){
    return <>
        <p>Page Faq</p>
    </>
}