export default function Contact(){
    return <>
        <p>Page Contact</p>
    </>
}