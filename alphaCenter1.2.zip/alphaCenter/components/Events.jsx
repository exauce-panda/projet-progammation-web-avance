export default function Events(){
    return <>
        <p>Page events</p>
    </>
}